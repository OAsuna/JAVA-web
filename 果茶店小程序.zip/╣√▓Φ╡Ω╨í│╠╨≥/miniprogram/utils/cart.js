var e = require("./sf");
const db = wx.cloud.database({});
module.exports = {
   //购物车添加数据
    add: function(data, o) {
      var _data = data;
      const u_openid = wx.getStorageSync('u_openid');
      db.collection("cart").where({
        _openid:u_openid,
        sku_base_id: _data.sku_base_id
      }).get({
        success(res){
          if(res.data.length>0){
            var all_price = Number(res.data[0].all_price) + Number(_data.all_price);
            var sku_count = Number(res.data[0].sku_count) + Number(_data.sku_count);
            db.collection("cart").doc(res.data[0]._id).update({
              data: {
                all_price: all_price,
                sku_count: sku_count
              },
              success(res){ 
                e.showToast("商品成功加入购物车"); 
                o(); 
              },
              fail: console.error
            })
          }else{
            db.collection("cart").add({
              data: _data,
              success(res) {
                e.showToast("商品成功加入购物车1"), o();
              }, fail(res) {
              }
            })
          }
        }
      })  
    },
    //获取购物车列表数据
    list: function() {
      const u_openid = wx.getStorageSync('u_openid');
      db.collection("cart").where({
        _openid: u_openid
      }).count({
        success(res){
          wx.setStorageSync("cart", res.total);
          wx.setTabBarBadge({
            index: 2,
            text: res.total.toString()
          });
        }
      });
    },
    //更新购物车数据
    update: function (data, func){
      wx.cloud.callFunction({
        // 云函数名称
        name: 'cart',
        // 传给云函数的参数
        data: {
          data: data,
          flag: 'update'
        },
        success(res) {
          func(0);
        },
        fail() {
          func(-1)
          console.error
        }
      })
    },
    //删除购物车数据
    remove: function (id, func) {
      wx.cloud.callFunction({
        // 云函数名称
        name: 'cart',
        // 传给云函数的参数
        data: {
          id: id,
          flag: 'del'
        },
        success(res) {
          func(0);
          wx.hideLoading();
        },
        fail(){
          func(-1)
          console.error
        } 
      });
    }
};