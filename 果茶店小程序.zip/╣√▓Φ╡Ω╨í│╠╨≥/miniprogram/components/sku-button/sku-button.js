Component({
    properties: {
        number: {
            type: Number,
            value: 0
        },
        max: {
            type: Number,
            value: 0
        }
    },
    methods: {
        handleIncrease: function() {
            var e = this.properties, max = e.max, num = e.number;
            max && num >= max || this.triggerEvent("increase", num + 1);
        },
        handleDecrease: function() {
            this.triggerEvent("decrease", this.properties.number - 1);
        }
    }
});