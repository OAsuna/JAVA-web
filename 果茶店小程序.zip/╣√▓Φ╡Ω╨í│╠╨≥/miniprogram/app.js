App({
  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        traceUser: true, //开启后小程序会自动记录用户的openid和用户信息，并且在请求时会自动带入openId，无需再进行鉴权。
      })
    }
    this.login();
  },
  login(){   //登录获取openid信息
    wx.cloud.callFunction({
      name: 'login',
      success(res) {
        wx.setStorageSync("u_openid",res.result.openid);
      }
    })
  },
  onShow: function(){
    //获取购物车数量，设置到tabBarBadge中
    var cartCount = wx.getStorageSync('cart');
    if(cartCount && cartCount > 0){
      wx.setTabBarBadge({
        index: 2,
        text: cartCount.toString()
      });
    }
  }
})
