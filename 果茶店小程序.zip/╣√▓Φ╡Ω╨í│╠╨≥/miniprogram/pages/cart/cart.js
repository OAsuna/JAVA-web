var formatDate = require("../../utils/formatDate");

const db = wx.cloud.database({});
Page({

  /**
   * 页面的初始数据
   */
  data: {
    startX: 0,  //开始位置X坐标值
    startY: 0,   //开始位置Y坐标值
    selectedAllStatus: 1,  //是否全部选中状态
    scrollY: true,     ////是否允许纵向滚动
    windowHeight: 500,   //购物车页面高度
    sku: [],    //购物车数据
    total_price: 0   //总价
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getlist();
  },
  //手势事件，用于滑动删除功能
  handleTouchstart: function (t) {
    this.data.sku.forEach(function (t, e) {
      t.isTouchMove && (t.isTouchMove = false);
    });
    this.setData({
      startX: t.changedTouches[0].clientX,
      startY: t.changedTouches[0].clientY,
      sku: this.data.sku
    });
  },
  //手势事件，用于滑动删除功能
  handleTouchmove: function (t) {
    var that = this, idx = t.currentTarget.dataset.index, data = that.data, startX = data.startX, startY = data.startY, clientX = t.changedTouches[0].clientX, clientY = t.changedTouches[0].clientY, obj = that.angle({
      X: startX,
      Y: startY
    }, {
        X: clientX,
        Y: clientY
      });

    that.data.sku.forEach(function (t, n) {
      t.isTouchMove = false, Math.abs(obj) > 40 || n === idx && (that.setData({
        scrollY: false
      }), t.isTouchMove = !(clientX > startX));
    });
    that.setData({
      sku: that.data.sku
    });
  },
  //手势事件，用于滑动删除功能
  handleTouchend: function () {
    this.setData({
      scrollY: true
    });
  },
  angle: function (t, e) {
    var n = e.X - t.X, s = e.Y - t.Y;
    return 360 * Math.atan(s / n) / (2 * Math.PI);
  },
  //删除
  catchLeftDel: function (t) {
    var that = this, dataset = t.currentTarget.dataset, item_id = dataset.item_id, index = dataset.index, sku = this.data.sku, o = [];
    o.push(item_id)
    wx.cloud.callFunction({
      name: 'cart',
      data: {
        flag: 'del',
        id: o
      },
      success(res) {
        that.getlist();
      },
      fail() {
        console.error
      }
    });
  },
  //全选
  bindSelectAll: function () {
    var that = this, selectedAllStatus = this.data.selectedAllStatus, sku = this.data.sku, flag =  !selectedAllStatus;
    var all_price = 0;
    for (var i = 0; i < sku.length; i += 1){
      sku[i].is_chosen = flag;
      sku[i].sku_detail.is_sold_out ? sku[i].is_chosen = !1 : sku[i].is_chosen = flag;
      all_price = all_price + sku[i].all_price
    } 
    that.setData({
      selectedAllStatus: !selectedAllStatus,
      sku: sku,
      total_price: !selectedAllStatus ? all_price : 0
    });
  },
  //绑定点击checkbox事件
  bindCheckbox: function (t) {
    var that = this, 
        sku = this.data.sku, 
        index = t.currentTarget.dataset.index,
        c_sku = sku[index], 
        is_chosen = sku[index].is_chosen,
        id = sku[index]._id;
    if (1 === sku[index].is_sold_out) return false;
    is_chosen = !is_chosen;
    var o = new Object();
    o.id = id;
    o.is_chosen = is_chosen;
    wx.cloud.callFunction({
      name: 'cart',
      data: {
        flag: 'update',
        data: o
      },
      success(res) {
        that.getlist();
      },
      fail() {
        console.error
      }
    });
  },
  //获取商品列表
  getlist:function(){
    var that = this;
    const u_openid = wx.getStorageSync('u_openid');
    db.collection("cart").where({
      _openid: u_openid
    }).get({
      success(res) {
        var total_price = 0;
        if(res.data.length > 0){
          for (var i = 0; i < res.data.length; i++) {
            if(res.data[i].is_chosen){
              total_price = total_price + res.data[i].all_price
            }
          }
        }
        
        that.setData({
          sku: res.data,
          total_price: total_price
        })
        that.getCartCount();
      }
    });
  },
  //获取购物车数量设置TabBarBadge
  getCartCount: function(){
    const u_openid = wx.getStorageSync('u_openid');
    db.collection("cart").where({
      _openid: u_openid
    }).count({
      success(res) {
        wx.setStorageSync("cart", res.total);
        wx.setTabBarBadge({
          index: 2,
          text: res.total.toString()
        });
      }
    });
  },
  //绑定“选好了”按钮事件，用于提交数据
  handlechange: function () {
    var sku = this.data.sku, new_sku = sku.filter(function (t) {
      return t.is_chosen;
    }).map(function (t) {
      return t;
    });
    if (0 === new_sku.length) {
      wx.showToast({
        title: "请选择至少一种商品",
        icon: "none"
      });
    } else {
      var orderNo = new Date().getTime();
      var createTime = formatDate(orderNo);
      var arr = new Array();
      var cartIds = new Array();
      for(var i=0; i<new_sku.length; i++){
        var _data = new Object();
        _data["orderNo"] = orderNo+"";
        _data["status"] = 0;
        _data["isMove"] = 0;
        _data["create_time"] = createTime;
        _data["count"] = new_sku[i].sku_count;
        _data["all_price"] = new_sku[i].all_price;
        _data["skulist"] = new_sku[i].sku_detail;
        _data["remark"] = "";
        cartIds.push(new_sku[i]._id);
        arr.push(_data);
      }
      wx.cloud.callFunction({
        name: 'order',
        data: {
          flag: 'add',
          data: arr
        },
        success(res) {
          wx.cloud.callFunction({
            name: "cart",
            data:{
              flag: 'del',
              id: cartIds
            },
            success(r){},
            fail(){
              console.log("err")
            }
          })
          wx.navigateTo({
            url: "/pages/order/confirm?from=cart&orderNo=" + orderNo
          });
        },
        fail() {
          console.error
        }
      });
    }
  }
})