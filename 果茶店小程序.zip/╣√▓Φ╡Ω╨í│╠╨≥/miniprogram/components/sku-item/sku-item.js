Component({
  properties: {
    detail: {
      type: Object,
      value: {}
    },
    count: {
      type: Number,
      value: 0
    }
  },
  methods: {
    //添加购物车事件，通过"triggerEvent"出发绑定该自定义组件上的click事件。
    handleIncrease: function () {  
      var data = this.properties, _detail = data.detail, _count = data.count;
      this.triggerEvent("click", {  
        detail: _detail,
        count: _count
      });
    },
    //弹出商品信息弹出组件事件，通过"triggerEvent"出发绑定该自定义组件上的select事件。
    handleTap: function () {   
      var e = this.properties.detail;
      this.triggerEvent("select", {  
        detail: e
      });
    }
  }
});