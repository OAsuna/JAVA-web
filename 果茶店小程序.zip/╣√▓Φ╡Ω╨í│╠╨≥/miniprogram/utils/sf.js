var o = Object.assign || function(o) {
    for (var n = 1; n < arguments.length; n++) {
        var t = arguments[n];
        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (o[r] = t[r]);
    }
    return o;
};

module.exports = {
    showToast: function(o) {
        var n = o;
        "string" == typeof o && (n = {
            icon: "none",
            title: o
        }), n.icon || (n.icon = "none"), wx.showToast(n);
    },
    showModal: function(n) {
        wx.showModal(o({
            confirmColor: "#98002E"
        }, n));
    }
};