var showObj = require("../../utils/sf");
Component({
    properties: {
        detail: {
            type: Object,
            value: {},
            observer: function(t) {
                if (t) {
                  this.setData({
                    scrollHeight: 364
                  })
                }
            }
        },
        visible: {
            type: Boolean,
            value: 0,
            observer: function(t) {
                if (t) {
                  this.setData({
                    sku_id: 0,
                    count: 1,
                    price: 0,
                    top: 0
                  });
                  this.calPrice();
                }
            }
        },
    },
    data: {
        scrollHeight: 0,
        sku_id: 0,
        count: 1,
        price: 0,
        top: 0
    },
    methods: {
        //计算价格
        calPrice: function() {
          var count = this.data.count, _price = this.properties.detail.price;
            this.setData({
              price: Number(_price) * Number(count)
            });
        },
        //绑定sku-button中的increase与decrease事件的方法，用于设置购买数量
        handleCount: function(t) {
            if(Number(t.detail)!== 0){
              this.setData({
                count: t.detail
              });
              this.calPrice();
            }
        },
        //用于返回所选择后的商品信息
      formatSku: function () {
        var detail = this.properties.detail, data = this.data, count = data.count;
        return  [{
          sku_base_id: detail.sku_base_id,
          sku_count: count,
          all_price: data.price,
          sku_detail: detail,
          is_chosen: 1,
          isTouchMove: 0
        }];
      },
       //加入加入购物车事件
        onSelect: function() {
            var count = this.data.count;
          this.properties.detail.is_sold_out ? showObj.showToast("商品已售罄") : count <= 0 ? showObj.showToast("商品数量不能为0") : (this.triggerEvent("select", this.formatSku()), 
            this.calPrice());
        },
        //立即购买事件
        onBuy: function() {
            var count = this.data.count, all_price = this.data.price, detail = this.properties.detail;
          if (detail.is_sold_out){
            showObj.showToast("商品已售罄");
          }  else if (count <= 0){
            showObj.showToast("商品数量不能为0");
          }  else {
                this.triggerEvent("buy", {
                  count: count,
                  all_price: all_price,
                  detail: detail
                });
                this.calPrice();
            }
        },
        //关闭窗口事件
        onClose: function() {
             this.triggerEvent("close");
        }
    }
});