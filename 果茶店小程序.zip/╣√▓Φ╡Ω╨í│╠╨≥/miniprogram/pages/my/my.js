Page({
  data: {
    links: [{
      icon: "/assert/my/my_address.png",
      title: "地址管理",
      url: "/pages/address/manage"
    }],
  },
  //用户点击右上角分享
  onShareAppMessage: function (res) {
    return {
      title: "小程序云开发",
      path: "/pages/index/index"
    }
  }
})