var cart = require("../../utils/cart"); //引用购物车公众方法
var showToast = require("../../utils/sf"); //引用Toast提示框组件
var QQMapWX = require("../../utils/qqmap-wx-jssdk.min");  //引用地图SDK
var formatDate = require("../../utils/formatDate"); //引用时间格式化插件
var s = null;   //setTimeout 全局实例
//实例化地图插件
var qqmapsdk = new QQMapWX({
  key: 'OLLBZ-NZHC6-4ELS3-EZ4G7-EPOCH-4VBFR'
});
//实例化云数据库
const db = wx.cloud.database({});
Page({
  //页面的初始数据
  data: {
    //isOpen: 1,
    categoryName : "强烈推荐",   //默认类别名
    cart: [],    //存放购物车数组
    active: 0,  //当前选中态
    skuList:[],  //存放商品信息数组
    showPopup: false,   //是否显示弹窗组件标识
    bannerList : [],   //存放banner图片列表
    windowHeight: 0,    //用来动态设置整个页面的height
    scrollTop: 0,      //用来动态设置滚动条的位置，提升用户体验
    shoplistScollTop: 0,   //用来动态设置商品与分类所对应的位置
    menuHeight: "100%",  //用来动态设置menu的height
    menuItemHeight: 60,   //用来动态设置产品列表height
    bannerHeight: 169,   //用来动态设置轮播图 height
    currentSwiper: 0,     //当前swiper轮播图焦点
    showNoAddress : 0,    //获取定位失败提示标识位
    locationAddress:'',   //存储当前位置信息
    currentSku : null,    //存储当前选中的商品信息
    tops: []              //存储当前分类菜单高度信息
  },
  swiperChange: function (t) {  //设置swiper焦点
    this.setData({
      currentSwiper: t.detail.current
    });
  },
  //生命周期函数--监听页面加载
  onLoad: function (options) {
    this.getBanner();  
    this.getLocation();
  },
  //获取轮播图数据
  getBanner(){
    var that = this;
    //wx.cloud.init
    //从云存储获取轮播图数据
    db.collection('banner').get({
      success(res) {
        console.log(res.data)
        that.setData({
        
          bannerList: res.data
        })
        that.setBanner();
      },
      fail(err) {
        console.log("err.", err)
      }
    });
  },
  setBanner(){  //获取屏幕信息，根据比例设置轮播图的width、height
    var that = this, sysInfo = wx.getSystemInfoSync(), screenWidth = sysInfo.screenWidth, winHeight = sysInfo.windowHeight, model = sysInfo.model, bannerHeight = 0;
    //createSelectorQuery 可以获取页面实例，通过这个方法能获取到页面的class为bannerWrap的height
    wx.createSelectorQuery().select(".bannerWrap").boundingClientRect(function (e) {
      bannerHeight = e.height;
      that.setData({
        windowHeight: winHeight,
        menuItemHeight: screenWidth / 750 * 120,
        bannerHeight: bannerHeight,
        menuHeight: winHeight - screenWidth / 750 * 90
      });
    }).exec();
  },
  //绑定外层滚动事件，滚动时出发，返回。增加用户体验
  handleUpper: function (e) {  
    let that = this;
    s&&clearTimeout(s);
    if(e.detail.scrollTop < parseInt(that.data.bannerHeight)){
      s = setTimeout(function () {
        that.setData({
          scrollTop: 0
        })
      }, 500);
    }
  },
  //点击左侧分类时间绑定方法
  handleGroupSelect: function (t) {
    //获取当前分类数组中索引信息,以便根据index索引查询数据
    var _index = t.currentTarget.dataset.index;
    var _data = this.data;
    //获取保存在this.data数据中的bannerHeight，根据bannerHeight滑动页面隐藏轮播图
    var _bannerHeight = _data.bannerHeight;
    var _tops = _data.tops;
    //获取this.data数据中所有商品信息
    var _skulist = _data.skuList;
    this.setData({
      active: _index,
      categoryName: _skulist[_index].category_name || "",
      scrollTop: _bannerHeight,
      shoplistScollTop: _tops[_index - 1] || 0
    });
  },
  //获取分类信息height已经商品列表height
  getTops: function () {
    var that = this, selectQuery = wx.createSelectorQuery();
    selectQuery.select(".center-bar").boundingClientRect(function (e) {
      var winHeight = wx.getSystemInfoSync().windowHeight;
      if(e && e.height){
        that.setData({
          menuHeight: winHeight - e.height
        });
      }
    }).exec();
    selectQuery.selectAll(".shop-list__item").boundingClientRect(function (e) {
      var a = [];
      e.forEach(function (t, e) {
        0 === e ? a.push(t.height) : a.push(t.height + a[e - 1]);
      });
      that.setData({
        tops: a
      });
    }).exec();
  },
  //商品滚动事件绑定方法
  shopListScroll: function (t) {  
    var _detail = t.detail;
    var _scrollTop = _detail.scrollTop;
    var _deltaY = _detail.deltaY;
    var _data = this.data;
    var _active = _data.active;
    var _tops = _data.tops;
    //获取商品列表信息
    var _skuList = _data.skuList;
    console.log("_active:", _active)
    console.log("_deltay:", _deltaY);
    if (_deltaY > 0){
      //通过滑动取个当前索引值，设置当前分类名称
      for (var i = _active - 1; i >= 0; i -= 1){
        _scrollTop < _tops[i] && _scrollTop > (_tops[i - 1] || 0) && this.setData({
          active: i,
          categoryName: _skuList[i].category_name || ""
        });
      } 
    }else{
      //通过滑动取个当前索引值，设置当前分类名称
      for (var j = _active; j < _tops.length - 1; j += 1){
        _scrollTop > _tops[j] && _scrollTop < _tops[j + 1] && this.setData({
          active: j + 1,
          categoryName: _skuList[j + 1].category_name || ""
        });
      }
    } 
  },
  //点击商品列表绑定事件，做方法用来当点击商品列表某处时，隐藏轮播图，提升用户体验
  handleTouchStart: function () {
    var _data = this.data, _bannerHeight = _data.bannerHeight;
    _data.scrollTop < _bannerHeight && this.setData({
      scrollTop: _bannerHeight
    })
  },
  //用于绑定sku-item自定义组件中的click事件。
  handleSkuClick: function (t) {
    var _data = t.detail, _detail = _data.detail, _count = _data.count, _current = this.data.current; 
    if (_detail.is_sold_out){
      showToast.showToast("商品已售罄");
    }  else {
      cart.add({
          sku_base_id: _detail.sku_base_id,
          sku_count: _count,
          all_price: _detail.price,
          sku_detail: _detail,
          is_chosen: 1,
          isTouchMove: 0
        }, function(){
          cart.list();
        });
    } 
  },
  //用于绑定sku-item自定义组件中的select事件。弹出popup自定义组件
  handleSkuTap: function (t) {
    var detail = t.detail.detail;
    this.setData({
      showPopup: true,
      currentSku: detail
    });
  },
  //绑定自定义组件popup中的添加购物车事件
  handleSkuSelect: function(t){
    var that = this;
    cart.add(t.detail[0], function () {
      cart.list(), that.handlePopupClose();
    });
   
  },
  //绑定自定义组件popup中的购买事件
  handleSkuBuy: function (t) { 
     var orderNo = new Date().getTime();
     var createTime = formatDate(orderNo);
     var data = {
       "orderNo": orderNo + "",
       "status" : 0,
       "isMove": 0,
       "create_time": createTime,
       "count": t.detail.count,
       "all_price": t.detail.all_price,
       "skulist": t.detail.detail,
       "remark":""
     }
    db.collection("order").add({
      data: data,
      success(res) {
        console.log("res...", res);
        wx.navigateTo({
          url: "/pages/order/confirm?from=home&orderNo="+orderNo
        });
      }, fail(res) {}
    })
  },
  //关闭 PopupClose
  handlePopupClose: function () {  
    this.setData({
      showPopup: false,
      currentSku: {}
    });
  },
  //获取定位信息
  getLocation: function () {  
    var that = this;
    wx.getLocation({
      type: "gcj02",
      success: function (e) {
        qqmapsdk.reverseGeocoder({
          location: {
            latitude: e.latitude,
            longitude: e.longitude
          },
          get_poi: 0,
          success: function (res) {
            if (res.status == 0) {             
              that.setData({
                showNoAddress: 0,
                locationAddress: res.result.address_component.city + res.result.address_component.district + res.result.address_component.street_number
              })
              that.getSkuList()
             
            } else {
              that.setData({
                showNoAddress: 1
              })
            }
          },
          fail: function (error) {
            that.setData({
              showNoAddress: 1
            })
          }
        });
      },
      fail: function () {
      
        that.setData({
          showNoAddress: 1
        })
      }
    });
  },
  //获取商品列表
  getSkuList: function () {  
    wx.showLoading();
    var that = this;
    var arr = new Array();
    db.collection('product').get({
      success(res){
        that.setData({
          skuList:res.data
        })
        that.getTops()
      },
      fail(err){
        console.log("err.", err)
      },
      complete: function (e) {
        wx.hideLoading();
      }
    });
  },
})