const db = wx.cloud.database({});
const t_sku = db.collection('t_sku_type');
Page({
  data: {
    packageList:[],  //订单列表数据
    scrollY: true,   //是否允许纵向滚动
    startX: 0,  //开始位置X坐标值
    startY: 0, //开始位置Y坐标值
    endX: 0,    //结束位置X坐标值
    endY: 0,   //结束位置Y坐标值
    showpackageDelete: false,  //默认是否显示删除按钮
    orderNo: 0    //订单号
  },
  //获取订单列表数据
  getPackageList: function(){
    wx.showLoading();
    var that = this;
    const u_openid = wx.getStorageSync('u_openid');
    db.collection("order").where({
      _openid: u_openid
    }).get({
      success(res) {
        wx.hideLoading();
        that.setData({
          packageList: res.data
        })
      }
    });
  },
  //绑定“取消订单”按钮事件方法
  cancelOrder(a){
    var _oid = a.currentTarget.dataset.id;
    var that = this;
    wx.cloud.callFunction({
      name: 'order',
      data: {
        orderNo: _oid,
        flag: 'update',
        status: 2
      },
      success(res) {
        console.log(res);
        that.getPackageList();
      },
      fail: wx.hideLoading()
    });
  },
  //绑定“立即支付”按钮事件方法
  payOrder: function (o) {
    wx.showLoading();
    var _oid = o.currentTarget.dataset.id;
    var that = this;
    wx.cloud.callFunction({
      name: 'order',
      data: {
        orderNo: _oid,
        flag: 'update',
        status: 1
      },
      success(res) {
        wx.hideLoading();
        that.getPackageList();
      },
      fail: console.error
    });
  },
  //生命周期函数--监听页面显示
  onShow: function () {
    this.getPackageList();
  }
})