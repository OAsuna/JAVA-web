const cloud = require('wx-server-sdk')
cloud.init()
const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
  //订单标识位 add、update、del
  var flag = event.flag;  
  switch(flag){
    case "add":  //订单添加
      try {
        //获取订单数据
        var _data = event.data; 
        //如果数组形式，则为多个订单批量添加，否则添加一条订单
        if(Array.isArray(_data)){  
          var res = null;
          for(var i=0; i<_data.length; i++){
            //订单批量添加
            res = await db.collection('order').add({
              data: _data[i]
            })
          }
          return res;
        }else{
          //添加一条订单
          return await db.collection('order').add({ 
            data: _data
          })
        }
      } catch (e) {
        console.error(e)
      }
      break;
    case "update":  //修改订单状态
      try {
        var orderNo = event.orderNo;
        var status = event.status;
        //根据订单号，修改订单状态
        return await db.collection('order').where({
          orderNo: orderNo
        }).update({
            data: {
              status: status
            },
          })
      } catch (e) {
        console.error(e)
      }
      break;
    case "del":  //删除订单
      try {
        //根据订单号删除订单
        var orderNo = event.orderNo;
        return await db.collection('order').where({
          orderNo: orderNo
        }).remove();
      } catch (e) {
        console.error(e)
      }
      break;
  }
}