const cloud = require('wx-server-sdk');
//初始化
cloud.init();
//获取数据库引用
const db = cloud.database();
//云函数入口
exports.main = async (event, context) => {
  //客户端标识位. flag == update 为更新； flag == del 为删除。
  var flag = event.flag; 
  switch (flag) {
    case "update":
      try {
        //获取cart ID
        var id = event.data.id;
        //获取是否选中值
        var is_chosen = event.data.is_chosen;
        return await db.collection('cart').where({
          _id: id+""
        }).update({
          data: {
            is_chosen: is_chosen
          },
        })
      } catch (e) {
        console.error(e)
      }
      break;
    case "del":
      //获取id数组，批量删除
      var ids = event.id;
      try {
        if (Array.isArray(ids)) {
          var res = null;
          for(var i=0; i<ids.length; i++){
            res = await db.collection('cart').where({
              _id: ids[i]
            }).remove();
          }
          return res;
        }
      } catch (e) {
        console.error(e)
      }
      break;
  }
}